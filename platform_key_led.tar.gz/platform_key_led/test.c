#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
int main(int argc, const char *argv[])
{
	int fd;
	int status;
	if((fd = open("/dev/platform_key_led",O_RDWR)) == -1){
		perror("open error");
		return -1;
	}
	while(1){
		read(fd,&status,sizeof(status));
		printf("led status = %d\n",status);
	}

	close(fd);
	return 0;
}
