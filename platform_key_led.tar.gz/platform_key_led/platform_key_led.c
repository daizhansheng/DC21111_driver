#include <linux/init.h>
#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/mod_devicetable.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/of.h>
#include <linux/of_irq.h>
#include <linux/gpio/consumer.h>
#include <linux/interrupt.h>
#include <linux/device.h>

#define CNAME "platform_key_led"
int major;
struct class *cls;
struct device *dev;
wait_queue_head_t wq;
int condition = 0;
int number=0;
struct device_node *node;
struct gpio_desc *gd;
int irqno;
/*
myplatform{
    compatible = "hqyj,myplatform";
    reg = <0x12345678 0x14>;      //platform_get_resource(,IORESOURCE_MEM,)
    interrupt-parent = <&gpiof>;
    interrupts = <9 0>;         //platform_get_irq();
    led1 = <&gpioe 10 0>;       //û��ֱ�ӽ�����gpio�Ż�gpio_desc,��Ҫ�Լ�����
};   

*/
irqreturn_t key_led_irq_handle(int irq, void * dev)
{
	//1.�޸ĵƵ�״̬ ,�޸�number
	number = !number;
	gpiod_set_value(gd,number);
	
	//3.��������
	condition = 1;
	wake_up_interruptible(&wq);

	return IRQ_HANDLED;
}

int key_led_block_open(struct inode *inode, struct file *file)
{
	printk("%s:%d\n",__func__,__LINE__);
	return 0;
}

ssize_t key_led_block_read(struct file *file, 
	char __user *ubuf, size_t size, loff_t *offs)
{
	int ret;
	if(file->f_flags &O_NONBLOCK){
		//������
		return -EINVAL;
	}else{
		//����
		ret = wait_event_interruptible(wq,condition);
		if(ret){
			printk("receive signal.....\n");
			return ret;
		}
	}

	if(size > sizeof(number)) size = sizeof(number);
	ret = copy_to_user(ubuf,&number,size);
	if(ret){
		printk("copy data to user error\n");
		return -EIO;
	}

	condition = 0;
	
	return size;
	
}
	
int key_led_block_close(struct inode *inode, struct file *file)
{
	printk("%s:%d\n",__func__,__LINE__);
	return 0;
}

const struct file_operations fops = {
	.open = key_led_block_open,
	.read = key_led_block_read,
	.release = key_led_block_close,
};

int pdrv_probe(struct platform_device *pdev)
{
	int ret;
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	//��ȡgpio��/ע��gpio
	gd = gpiod_get_from_of_node(pdev->dev.of_node,"led1",0,GPIOD_OUT_LOW,NULL);
	if(IS_ERR(gd)){
		printk("get gpio desc error\n");
		return PTR_ERR(gd);
	}
	number = gpiod_get_value(gd);
	

	irqno = platform_get_irq(pdev,0);
	if(irqno <0){
		printk("platform get irq error\n");
		return irqno;
	}
		//ע���ж�
	ret = request_irq(irqno,key_led_irq_handle,IRQF_TRIGGER_FALLING,CNAME,NULL);
	if(ret){
		printk("register irq error\n");
		return ret;
	}
	
	//��ʼ���ȴ�����ͷ
	init_waitqueue_head(&wq);
	
	//ע���ַ��豸����
	major = register_chrdev(0,CNAME,&fops);
	if(major < 0){
		printk("register char device driver error\n");
		return -EAGAIN;
	}
	
	//�Զ������豸�ڵ�
	cls = class_create(THIS_MODULE,CNAME);
	if(IS_ERR(cls)){
		printk("class create error\n");
		return PTR_ERR(cls);
	}
	dev = device_create(cls,NULL,MKDEV(major,0),NULL,CNAME);
	if(IS_ERR(dev)){
		printk("device create error\n");
		return PTR_ERR(dev);
	}
	return 0;
}
int pdrv_remove(struct platform_device *pdev)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	device_destroy(cls,MKDEV(major,0));
	class_destroy(cls);
	unregister_chrdev(major,CNAME);
	free_irq(irqno,NULL);
	gpiod_put(gd);
	return 0;
}
struct of_device_id ofmatch[] = {
	{.compatible = "hqyj,myplatform",},
	{}  //ʹ���豸��ƥ���ʱ��һ��Ҫдһ��{},��ʾ����
};

struct platform_driver pdrv = {
	.probe = pdrv_probe,
	.remove = pdrv_remove,
	.driver = {
		.name = "duangduangduang",
		.of_match_table = ofmatch,
	}
};

static int __init pdrv_init(void)
{
	return platform_driver_register(&pdrv);
}

static void __exit pdrv_exit(void)
{
	platform_driver_unregister(&pdrv);
}
module_init(pdrv_init);
module_exit(pdrv_exit);
MODULE_LICENSE("GPL");

