#ifndef __MYLED_H__
#define __MYLED_H__

typedef struct{
	volatile unsigned int MODER;
	volatile unsigned int OTYPER;
	volatile unsigned int OSPEEDR;
	volatile unsigned int PUPDR;
	volatile unsigned int IDR;
	volatile unsigned int ODR;
}gpio_t;


enum{
	LED1,
	LED2,
	LED3,
};
enum{
	OFF,
	ON
};
#define LED1_ON _IO('a',0)
#define LED1_OFF _IO('a',1)
#endif


