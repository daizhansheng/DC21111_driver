#include <linux/init.h>
#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/io.h>
#include "myled.h"

#define CNAME "platform_led"
int major;
gpio_t *gpioe_virt_base = NULL;
unsigned int *rcc_ahb4_virt = NULL;
struct resource * res[2];
struct class *cls;
struct device *dev;

void led_init(struct resource *res1,struct resource *res2)
{
	//1.��ַӳ��
	gpioe_virt_base = ioremap(res1->start,(res1->end-res1->start+1));
	if(gpioe_virt_base == NULL){
		printk("gpio ioreamp  error\n");
		return ;
	}

	rcc_ahb4_virt = ioremap(res2->start,(res2->end-res2->start+1));
	if(rcc_ahb4_virt == NULL){
		printk("rcc ioreamp  error\n");
		return ;
	}
	//��ʼ��LED
	*rcc_ahb4_virt |= (1<<4);  //rcc gpioe enable
	gpioe_virt_base->MODER &= ~(3<<20); //clear 21-20 bit
	gpioe_virt_base->MODER |= (1<<20); //set bit 20   output
	gpioe_virt_base->ODR   &=~(1<<10); //led1 off

}

int led_control(int which,int status)
{
	switch(which){
		case LED1:
			status==1?(gpioe_virt_base->ODR|=(1<<10)):(gpioe_virt_base->ODR &=~(1<<10));
			break;
		case LED2:
			break;
		case LED3:
			break;
		default:
			printk("led control error\n");
			return -EINVAL;
	}
	return 0;
}

int mycdev_open(struct inode *inode, struct file *file)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	
	return 0;
}

long mycdev_ioctl(struct file *file,
	unsigned int cmd, unsigned long args)
{
	switch(cmd){
		case LED1_ON:
			led_control(LED1,ON);
			break;
		case LED1_OFF:
			led_control(LED1,OFF);
			break;
	}

	return 0;
}

int mycdev_close(struct inode *inode, struct file *file)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	return 0;
}

const struct file_operations fops = {
	.open = mycdev_open,
	.unlocked_ioctl = mycdev_ioctl,
	.release = mycdev_close,
};

int pdrv_probe(struct platform_device *pdev)
{
	int i;
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	for(i=0;i<ARRAY_SIZE(res);i++){
		res[i] = platform_get_resource(pdev,IORESOURCE_MEM,i);
		if(res[i]== NULL){
			printk("platform get resource error\n");
			return -EINVAL;
		}
	}

	printk("addr_gpioe = %#x,addr_rcc = %#x\n",res[0]->start,res[1]->start);
	
	//�Ƶĳ�ʼ��
	led_init(res[0],res[1]);
	
	//1.�����ַ��豸����
	major = register_chrdev(0,CNAME,&fops);
	if(major < 0){
		printk("register char device driver error\n");
		return major;
	}

	printk("success,major = %d\n",major);
	//2.�Զ������豸�ڵ�

	cls = class_create(THIS_MODULE,CNAME);
	if(IS_ERR(cls)){
		printk("class create error\n");
		return PTR_ERR(cls);
	}

	dev = device_create(cls,NULL,MKDEV(major,0),NULL,CNAME);
	if(IS_ERR(dev)){
		printk("device create error\n");
		return PTR_ERR(dev);
	}

	
	return 0;
}
int pdrv_remove(struct platform_device *pdev)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	device_destroy(cls,MKDEV(major,0));
	class_destroy(cls);
	//�����ַ��豸����
	unregister_chrdev(major,CNAME);
	return 0;
}

struct platform_driver pdrv = {
	.probe = pdrv_probe,
	.remove = pdrv_remove,
	.driver = {
		.name = "duangduangduang",
	}
};

static int __init pdrv_init(void)
{
	return platform_driver_register(&pdrv);
}

static void __exit pdrv_exit(void)
{
	platform_driver_unregister(&pdrv);
}
module_init(pdrv_init);
module_exit(pdrv_exit);
MODULE_LICENSE("GPL");

