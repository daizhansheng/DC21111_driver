#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include "myled.h"


int main(int argc, const char *argv[])
{
	int fd;
	if((fd = open("/dev/platform_led",O_RDWR)) < 0){
		perror("open error");
		return -1;
	}
	while(1){
		ioctl(fd,LED1_ON);
		sleep(1);
		ioctl(fd,LED1_OFF);
		sleep(1);
	}
	close(fd);
	return 0;
}
